#ifndef CONNECTIONPOOL_H
#define CONNECTIONPOOL_H

#include "Connection.h"
#include <string>
#include <queue>
#include <mutex>
#include <atomic>
#include <thread>
#include <memory>
#include <functional>
#include <condition_variable>

/*
* 采用单例模式，实现数据库连接池的功能
*/

class ConnectionPool
{
public:
    // 获取连接池对象实例（懒汉式单例，在获取实例时才实例化对象）
    static ConnectionPool* getConnectionPool();

    // 从连接池中获取一个可用的空闲连接。
    // 这里直接返回一个智能指针，智能指针出作用域自动析构，（我们只需重定义析构即可：不释放而是归还）
    std::shared_ptr<Connection> getConnection();

private:
    // 单例模式：构造函数私有化
    ConnectionPool();

    // 从配置文件中加载配置项
    bool loadConfigFile();

    // 运行在独立的线程中，专门负责生产新连接。
    // 非静态成员方法，其调用依赖对象，要把其设计为一个线程函数，需要绑定this指针。 
    // 把该线程函数写为类的成员方法，最大的好处是 非常方便访问当前对象的成员变量。
    void produceConnectionTask();
};

#endif